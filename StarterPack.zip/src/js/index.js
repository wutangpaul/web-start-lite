

console.log('JS files successfully built, innit bruv');